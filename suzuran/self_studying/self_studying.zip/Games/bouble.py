from cv2 import cv2
import mediapipe as mp
import pygame
import numpy as np

width ,height = 1000, 700

screen = pygame.display.set_mode((width, height))
